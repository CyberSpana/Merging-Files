// Importing all the classes for reading and printing files
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class Merge {
	// Change the values for event and maxMatches every event
	private static final String event = "Chezy";
	private static final int maxMatches = 2;
	// Creating a reference to the Headers.txt file that is in the folder
	private static File headers = new File("Headers.txt");
	// Creating a File called Merged.txt file that will be printed in the folder
	private static File output = new File("Merged.txt");
	// Creating a reference to the FileWriter and PrintWriter
	public static FileWriter f;
	public static PrintWriter p;
	
	public static void main (String[] args) {
		// Creating the FileWriter and PrintWriter 
		try {
			f = new FileWriter(output);
			p = new PrintWriter(f);
		} 
		// Throwing an exception
		catch (IOException e) {
			e.printStackTrace();
		}
		// A reference to the headersPrint method that will print out the headers to the merged file 
		headersPrint();
		// A String that will hold the alliance color
		String color;
		// An integer that will hold the alliance number
		int allianceNum;
		for (int i = 0; i < maxMatches; i++) {
			for(int j = 0; j < 6; j++)  {
				if (j < 3) {
					allianceNum = j;
					color = "Red";
				} else {
					allianceNum = j - 3;
					color = "Blue";
				}
				matchesPrint(i + 1, color, allianceNum);
			}
		}
		// Closing the PrintWriter
		p.close();
	}
	
	// Printing out the headers to the merged file
	private static void headersPrint() {
		try {
			Scanner console = new Scanner(headers);
			String M = console.nextLine();
			p.println(M);
			console.close();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	private static void matchesPrint(int i, String color, int num) {
		try {
			File match = new File(event + "Match" + i + color + num + ".txt");
			Scanner console = new Scanner(match);
			String M = console.nextLine();
			p.println(M);
			console.close();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
